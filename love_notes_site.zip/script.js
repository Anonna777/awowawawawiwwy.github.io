document.getElementById('add-note-btn').addEventListener('click', () => {
  const noteText = prompt('Write your love note:');
  if (noteText) {
    const li = document.createElement('li');
    li.textContent = noteText;
    document.getElementById('notes-list').appendChild(li);
  }
});

document.getElementById('confetti-btn').addEventListener('click', () => {
  confetti({
    particleCount: 150,
    spread: 70,
    origin: { y: 0.6 }
  });
});
